# MenuStore
This include allows you to create many types of stores using Textdraws.

![MenuStore](https://i.imgur.com/gH1k6t4.jpg)

Doc
https://sampforum.blast.hk/showthread.php?tid=644913
